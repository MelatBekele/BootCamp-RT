"""
A Hello World Script.

This is a very, very simple script.

Author: Walker M. White (wmw2)
Date:   July 31, 2018
"""
print('Hello World!')